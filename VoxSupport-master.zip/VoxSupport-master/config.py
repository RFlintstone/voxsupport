# -------------------------------------------------------------- #
#                                                                #
# VoxSupport Configuration                                       #
#                                                                #
# -------------------------------------------------------------- #

token = 'YOUR TOKEN'

DEBUG = False
name = 'VoxSupport'
website = 'VoxSupport'
version = '1.0.0 DEV'
